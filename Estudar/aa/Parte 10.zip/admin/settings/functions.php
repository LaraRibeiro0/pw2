<?php
	function expulsaModerador(){
		if(isset($_SESSION['nivel']) && $_SESSION['nivel'] != 2){
			header('Location: ?pagina=inicio');
			exit;
		}
	}
?>