<center>
<div id="login" style="width: 400px;">
			<h3>Entrar</h3>

			<form action="" method="POST" enctype="multipart/form-data">
				<p><input type="text" name="usuario" id="usuario" placeholder="Usuário" class="form form-control"></p>
				<p><input type="password" name="senha" id="senha" placeholder="*********" class="form form-control"></p>
				<p><input type="submit" value="Entrar" class="btn btn-success" style="width: 120px;" /></p>
				<input type="hidden" name="entrar" value="login">
			</form>
		</div></center>

		<?php
			if(isset($_SESSION['nome']) && isset($_SESSION['usuario'])){
				header('Location: index.php?pagina=logado');
				exit;
			}

			if(isset($_POST['entrar']) && $_POST['entrar'] == "login"){
				$usuario = $_POST['usuario'];
				$senha = $_POST['senha'];

				if(empty($usuario) || empty($senha)){
					echo 'Preencha todos os campos!';
				}else{
					$query = "SELECT nome, usuario, senha, foto, nivel FROM usuarios WHERE usuario = '$usuario' AND senha = '$senha'";
					$result = mysql_query($query);
					$busca = mysql_num_rows($result);
					$linha = mysql_fetch_assoc($result);

					if($busca > 0){
						$_SESSION['nome'] = $linha['nome'];
						$_SESSION['usuario'] = $linha['usuario'];
						$_SESSION['foto'] = $linha['foto'];
						$_SESSION['nivel'] = $linha['nivel'];
						header('Location: ?pagina=logado');
						exit;
					}else{
						echo 'Usuário ou senha inválidos.';
					}
				}
			}

		?>