<div class="navbar navbar-default" align="left">
	<form action="" method="POST" enctype="multipart/form-data" class="form-inline" align="center">
		<h3>Digite o usuário que deseje buscar</h3>
		<hr/>
		<input type="text" name="busca" id="busca" placeholder="Digite sua busca" class="form form-control"/>
		<input type="submit" value="Buscar" class="btn btn-info"/>
		<input type="hidden" name="buscar" value="find"/>
	</form>
		<hr/>
	</div>
	<?php
		if(isset($_POST['buscar']) && $_POST['buscar'] == "find"){
		$busca = $_POST['busca'];
		if(empty($busca)){
			echo "<code>Preencha todos os campos!</code>";
		}else{
		$seleciona = mysql_query("SELECT * FROM usuarios WHERE nome LIKE '%$busca%' or usuario LIKE '%$busca%' ORDER BY id DESC LIMIT 20");
		$conta = mysql_num_rows($seleciona);

		if($conta <= 0){
			echo "<center>Nenhum usuário encontrado!</center>";
		}else{
			while($row = mysql_fetch_array($seleciona)){
				$nome = $row['nome'];
				$usuario = $row['usuario'];
				$foto = $row['foto'];
	?>
	<div id="panel">
		<p><img src="<?php echo $foto;?>" class="foto-user"/> <?php echo $nome;?> <b>@<?php echo $usuario;?></b></p>
		<p><a href="?pagina=editarusuario&usuario=<?php echo $usuario;?>" class="btn btn-warning">Editar</a> <?php if($_SESSION['nivel'] == 2){?><a href="?pagina=deletarusuario&usuario=<?php echo $usuario;?>" class="btn btn-danger">Deletar</a><?}?></p>
		</div>
	<?php }}}}?>