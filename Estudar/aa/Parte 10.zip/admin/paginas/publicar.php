<div class="well well-sm" align="center">
	<h3>Publicar</h3>
	<hr/>
	<p><code>Você também pode imporcorar links de redes sociais e outros sites.</code></p>
		<form action="" method="POST" enctype="multipart/form-data">
			<p><input type="text" name="titulo" id="titulo" placeholder="Insira um título" class="form form-control"/></p>
			<p><input type="text" name="postador" id="postador" placeholder="Nome do usuário" class="form form-control"/></p>
			<p><textarea name="descricao" id="descricao" placeholder="Diga algo sobre esta publicação." class="form form-control"></textarea></p>
			<p><input type="file" name="image" id="image" class="form form-control"/></p>
			<p align="right"><input type="submit" value="Publicar" class="btn btn-default"/></p>
			<input type="hidden" name="enviar" value="send"/>
		</form>
		<?php
			if(isset($_POST['enviar']) && $_POST['enviar'] == "send"){
				$titulo = $_POST['titulo'];
				$descricao = $_POST['descricao'];
				$postador = $_POST['postador'];

				date_default_timezone_set('America/Sao_Paulo');
				$data = date("d/m/Y");
				$hora = date("H:i:s");

				if(empty($titulo) || empty($postador)){
					echo "É obrigatório ter um titulo e colocar o nome do postador.";
				}else if($uploadfile != null){

				$uploaddir = '../imagens/uploads/';
				$uploadfile = $uploaddir.basename($_FILES['image']['name']);
				$imagename = $uploaddir.basename($_FILES['image']['name']);

				if(move_uploaded_file($_FILES['image']['tmp_name'], $uploadfile)){
					echo "Imagem enviada com sucesso";
					$query = "INSERT INTO posts (titulo, descricao, imagem, data, hora, postador) VALUES ('$titulo', '$descricao', '$imagename', '$data', '$hora', '$postador')";

					if(mysql_query($query)){
						echo "Publicação inserida com sucesso!";
					}

				}else{
					echo "Erro ao enviar a imagem";
				}

				}else{
					$query = "INSERT INTO posts (titulo, descricao, imagem, data, hora, postador) VALUES ('$titulo', '$descricao', '$imagename', '$data', '$hora', '$postador')";

					if(mysql_query($query)){
						echo "Publicação inserida com sucesso!";
					}
				}

				

			}

		?>
</div>