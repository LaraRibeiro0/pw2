<?php
	expulsaModerador();
?>
<center>
<div class="well well-sm">
		<h3>Cadastre-se</h3>

		<form action="" method="POST" enctype="multipart/form-data" align="left">
			<p><label>Nome</label></br> <input type="text" name="nome" id="nome" placeholder="Meu nome" class="form form-control"/></p>
			<p><label>Usuário</label></br> <input type="text" name="usuario" id="usuario" placeholder="Usuário" class="form form-control"/></p>
			<p><label>Senha</label></br> <input type="password" name="senha" id="senha" placeholder="**********" class="form form-control"/></p>
			<p><label>Foto</label></br> <input type="file" name="image" id="image" class="form form-control"/></p>
			<p align="right"><input type="submit" value="Cadastrar" class="btn btn-success" style="width: 120px;" /></p>
			<input type="hidden" name="cadastrar" value="register"/>
		</form>
	</div></center>

	<?php
		if(isset($_POST['cadastrar']) && $_POST['cadastrar'] == "register"){
			$nome = $_POST['nome'];
			$usuario = $_POST['usuario'];
			$senha = $_POST['senha'];
			$uploaddir = '../imagens/usuarios/';
			$uploadfile = $uploaddir.basename($_FILES['image']['name']);
			$imagename = $uploaddir.basename($_FILES['image']['name']);

			if(empty($nome) || empty($usuario) || empty($senha)){
				echo "Preencha todos os campos!";
			}else if($imagename != null){


			if(move_uploaded_file($_FILES['image']['tmp_name'], $uploadfile)){
				$query = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
				$result = mysql_query($query);
				$conta = mysql_num_rows($result);
				$busca = mysql_fetch_assoc($result);

				if($conta > 0){
					echo "Usuário já cadastrado.";
				}else{
					$cadastrar = "INSERT INTO usuarios (nome, usuario, senha, foto) VALUES ('$nome', '$usuario', '$senha', '$imagename')";
					if(mysql_query($cadastrar)){
						echo "Cadastro efetuado com sucesso!";
					}else{
						echo "Erro ao cadastrar, contate um administrador!";
					}
				}

			}
				
			}else{
			$query = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
			$result = mysql_query($query);
			$conta = mysql_num_rows($result);
			$busca = mysql_fetch_assoc($result);

			if($conta > 0){
					echo "Usuário já cadastrado.";
			}else{
			$cadastrar = "INSERT INTO usuarios (nome, usuario, senha) VALUES ('$nome', '$usuario', '$senha')";
			if(mysql_query($cadastrar)){
				echo "Cadastro efetuado com sucesso!";
			}else{
				echo "Erro ao cadastrar, contate um administrador!";
			}
		}
		}
	}
	?>