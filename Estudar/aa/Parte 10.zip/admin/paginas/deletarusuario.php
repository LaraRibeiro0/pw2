<div class="well well-sm" align="center">
	<form action="" method="POST" enctype="multipart/form-data">
		<h3><code>Tem certeza que deseja deletar este usuário?</code></h3>
		<p><input type="submit" value="Deletar" class="btn btn-danger"/></p>
		<input type="hidden" name="deletar" value="delete"/>
	</form>
	<?php
		$usuario = $_GET['usuario'];
		if(isset($_POST['deletar']) && $_POST['deletar'] == "delete"){
			$delete = "DELETE FROM usuarios WHERE usuario = '$usuario'";

			if(mysql_query($delete)){
				header('Location: ?pagina=usuarios');
			}else{
				echo "Erro ao deleta o usuário";
			}
		}
	?>
</div>