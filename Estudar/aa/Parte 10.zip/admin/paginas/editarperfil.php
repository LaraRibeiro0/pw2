<?php
	$idUser = $_SESSION['usuario'];
	$seleciona = mysql_query("SELECT * FROM usuarios WHERE usuario = '$idUser'");
	$linha = mysql_fetch_assoc($seleciona);
?>

<div class="well well-sm" align="center">
	<h3>Editar perfil</h3>
	<hr/>
	<form action="" method="POST" enctype="multipart/form-data">
		<p><input type="text" name="nome" id="nome" value="<?php echo $linha['nome'];?>" placeholder="Nome" class="form form-control" /></p>
		<p><input type="text" name="usuario" id="usuario" value="<?php echo $linha['usuario'];?>" placeholder="Usuário" class="form form-control" /></p>
		<p><input type="password" name="senha" id="senha" value="<?php echo $linha['senha'];?>" placeholder="***********" class="form form-control" /></p>
		<p><input type="file" name="image" id="image" class="form form-control"/></p>
		<p align="right"><input type="submit" value="Alterar dados" class="btn btn-success"/></p>
		<input type="hidden" name="alterar" value="change">
	</form>
	<?php
		if(isset($_POST['alterar']) && $_POST['alterar'] == "change"){
			$nome = $_POST['nome'];
			$usuario = $_POST['usuario'];
			$senha = $_POST['senha'];

			$uploaddir = '../imagens/usuarios/';
			$uploadfile = $uploaddir.basename($_FILES['image']['name']);
			$imagename = $uploaddir.basename($_FILES['image']['name']);

			if(empty($nome) || empty($usuario) || empty($senha)){
				echo "Preencha todos os campos antes de alterar";
			}else if($imagename != null){


			if(move_uploaded_file($_FILES['image']['tmp_name'], $uploadfile)){

				$alterar = "UPDATE usuarios SET nome = '$nome', usuario = '$usuario', senha = '$senha', foto = '$imagename' WHERE usuario = '$idUser'";
				if(mysql_query($alterar)){
					echo "Dados alterados com sucesso";
					$_SESSION['nome'] = $nome;
					$_SESSION['usuario'] = $usuario;
					$_SESSION['foto'] = $imagename;

			}else{
					echo "Erro ao enviar a imagem";
				}
			}else{
				$alterar = "UPDATE usuarios SET nome = '$nome', usuario = '$usuario', senha = '$senha' WHERE usuario = '$idUser'";
				if(mysql_query($alterar)){
					echo "Dados alterados com sucesso";
					$_SESSION['nome'] = $nome;
					$_SESSION['usuario'] = $usuario;	
			}else{
				echo "Erro ao alterar os dados!";
			}
		}
	}
}
	?>
</div>