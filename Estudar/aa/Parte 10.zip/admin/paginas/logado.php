<?php
	$nome = $_SESSION['nome'];
	$usuario = $_SESSION['usuario'];

?>
<div class="well well-sm" align="center">
	<h3>Bem vindo <?php $nome;?></h3>
	<hr>
	<p>Bem vindo ao painel, comece a usa-lo agora.</p>
</div>