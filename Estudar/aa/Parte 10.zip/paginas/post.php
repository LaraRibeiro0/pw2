<div class="well well-sm">
	<?php
		$idPost = $_GET['id'];

		$seleciona = mysql_query("SELECT * FROM posts WHERE id = '$idPost'");
		$conta = mysql_num_rows($seleciona);

		if($conta <= 0){
				echo "Post não encontrado";
		}else{
		while($row = mysql_fetch_array($seleciona)){
			$id = $row['id'];
			$titulo = $row['titulo'];
			$descricao = $row['descricao'];
			$imagem = $row['imagem'];
			$data = $row['data'];
			$hora = $row['hora'];
			$postador = $row['postador'];
			$sql = "SELECT * FROM usuarios WHERE usuario = '$postador'";
			$query = mysql_query($sql);
			$linha = mysql_fetch_assoc($query);

			$selecionaCurtidas = mysql_query("SELECT * FROM curtidas WHERE id_post = '$id'");
			$contaCurtidas = mysql_num_rows($selecionaCurtidas);

			if($contaCurtidas == 1){
				$contaCurtidas = $contaCurtidas." curtiu";
			}else if($contaCurtidas > 1){
				$contaCurtidas = $contaCurtidas." curtiram";
			}

			$selecionaComentarios = mysql_query("SELECT * FROM comentarios WHERE id_post = '$id'");
			$contaComentarios = mysql_num_rows($selecionaComentarios);

			if($contaComentarios == 1){
				$contaComentarios = $contaComentarios." comentou";
			}else if($contaComentarios > 1){
				$contaComentarios = $contaComentarios." comentaram";
			}
	?> 

	<div id="panel" align="left">
		<p><a href="" class="titulo"><?php echo $titulo;?></a></p>
		<?php if($descricao != null){?><p class="descricao"><?php echo $descricao;?></p><? }?>
		<?php if($imagem != null){?><p><img src="<?php echo $imagem;?>" class="foto"/></p><? }?>
		<p><span class="glyphicon glyphicon-time" aria-hidden="true"></span> Postado em: <?php echo $data." às ".$hora;?></br> <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Postado por: <?php echo $linha['nome'];?></p>
		<p><code><span class="glyphicon glyphicon-thumbs-up"></span> <?php echo $contaCurtidas;?></code> - <code><span class="glyphicon glyphicon-comment"></span> <?php echo $contaComentarios;?></code></p>
		<p><a href="?pagina=curtir&id=<?php echo $id;?>" class="btn btn-default"><span class="glyphicon glyphicon-thumbs-up"></span> Curtir</a> <a href="?pagina=post&id=<?php echo $id;?>" class="btn btn-default"><span class="glyphicon glyphicon-comment"></span> Comentar</a></p>
	</div>
	<?php }}?> 

	<div id="panel" align="left">
		<h3>Diga algo sobre esta publicação</h3>
		<hr/>
		<form action="" method="POST" enctype="multipart/form-data">
			<p><label>Nome</label></br> <input type="text" name="nome" id="nome" placeholder="Meu nome" class="form form-control"/></p>
			<p><textarea name="comentario" id="comentario" placeholder="Digite seu comentário" class="form form-control"></textarea></p>
			<p align="right"><input type="submit" value="Enviar comentário" class="btn btn-success"></p>
			<input type="hidden" name="comentar" value="comment">
		</form>
		<?php
			if(isset($_POST['comentar']) && $_POST['comentar'] == "comment"){
				$nome = $_POST['nome'];
				$comentario = $_POST['comentario'];

				date_default_timezone_set('America/Sao_paulo');
				$data = date("d/m/Y");
				$hora = date("H:i");

				if(empty($nome) || empty($comentario)){
					echo "Preencha todos os campos!";
				}else{
					$comentar = "INSERT INTO comentarios (id_post, nome, comentario, data, hora) VALUES ('$idPost', '$nome', '$comentario', '$data', '$hora')";

					if(mysql_query($comentar)){
						echo "Comentário enviado com sucesso!";
					}
				}

			}
		?>

		<hr>
		
			<?php
				$seleciona = mysql_query("SELECT * FROM comentarios WHERE id_post = '$idPost' ORDER BY id DESC");
				$conta = mysql_num_rows($seleciona);

				if($conta <= 0){
					echo "Este post ainda não possui comentários";
				}else{
					while($row = mysql_fetch_array($seleciona)){
						$nome = $row['nome'];
						$comentario = $row['comentario'];
						$data = $row['data'];
						$hora = $row['hora'];
			?>
				<div id="comentarios" class="well well-sm">
						<p><img src="imagens/nophoto.jpg" class="foto-comment"/> <b><?php echo $nome;?></b></p>
						<p class="list-group-item"><?php echo $comentario;?></p>
						<p class="list-group-item"><span class="glyphicon glyphicon-time" aria-hidden="true"></span> <?php echo $data." às ".$hora;?></p>
				</div>

			<?}}?>
	</div>

