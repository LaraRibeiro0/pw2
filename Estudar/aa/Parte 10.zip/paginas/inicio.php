<div class="well well-sm">
	<?php
		if(isset($_GET['posts'])){
			$pg = (int)$_GET['posts'];
		}else{
			$pg = 1;
		}

		$maximo = 2;
		$inicio = ($pg * $maximo) - $maximo;

		$seleciona = mysql_query("SELECT * FROM posts ORDER BY id DESC LIMIT $inicio, $maximo");
		$conta = mysql_num_rows($seleciona);

		if($conta <= 0){
			echo "<code>Nenhuma postagem cadastrada no banco de dados!";
		}else{
			while($row = mysql_fetch_array($seleciona)){
			$id = $row['id'];
			$titulo = $row['titulo'];
			$descricao = $row['descricao'];
			$imagem = $row['imagem'];
			$data = $row['data'];
			$hora = $row['hora'];
			$postador = $row['postador'];
			$sql = "SELECT * FROM usuarios WHERE usuario = '$postador'";
			$query = mysql_query($sql);
			$linha = mysql_fetch_assoc($query);

			$selecionaCurtidas = mysql_query("SELECT * FROM curtidas WHERE id_post = '$id'");
			$contaCurtidas = mysql_num_rows($selecionaCurtidas);

			if($contaCurtidas == 1){
				$contaCurtidas = $contaCurtidas." curtiu";
			}else if($contaCurtidas > 1){
				$contaCurtidas = $contaCurtidas." curtiram";
			}

			$selecionaComentarios = mysql_query("SELECT * FROM comentarios WHERE id_post = '$id'");
			$contaComentarios = mysql_num_rows($selecionaComentarios);

			if($contaComentarios == 1){
				$contaComentarios = $contaComentarios." comentou";
			}else if($contaComentarios > 1){
				$contaComentarios = $contaComentarios." comentaram";
			}



	?>

	<div id="panel" align="left">
		<p><a href="?pagina=post&id=<?php echo $id;?>" class="titulo"><?php echo $titulo;?></a></p>
		<?php if($descricao != null){?><p class="descricao"><?php echo $descricao;?></p><? }?>
		<?php if($imagem != null){?><p><img src="<?php echo $imagem;?>" class="foto"/></p><? }?>
		<p><span class="glyphicon glyphicon-time" aria-hidden="true"></span> Postado em: <?php echo $data." às ".$hora;?></br> <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Postado por: <?php echo $linha['nome'];?></p>
		<p><code><span class="glyphicon glyphicon-thumbs-up"></span> <?php echo $contaCurtidas;?></code> - <code><span class="glyphicon glyphicon-comment"></span> <?php echo $contaComentarios;?></code></p>
		<p><a href="?pagina=curtir&id=<?php echo $id;?>" class="btn btn-default"><span class="glyphicon glyphicon-thumbs-up"></span> Curtir</a> <a href="?pagina=post&id=<?php echo $id;?>" class="btn btn-default"><span class="glyphicon glyphicon-comment"></span> Comentar</a></p>

	</div>

	<?php }}?> 
</div>

<nav align="center">
	<ul class="pagination">
		<?php
		$seleciona = mysql_query("SELECT * FROM posts");
		$totalPosts = mysql_num_rows($seleciona);

		$pags = ceil($totalPosts/$maximo);
		$links = 2;
 
		echo '<li><a href="?pagina=inicio&posts=1" aria-label="Página Inicial"><span aria-hidde="true">&laquo;</span></a></li>';


		for($i = $pg - $links; $i <= $pg -1; $i++){
				if($i <= 0){}else{
			echo '<li><a href="?pagina=inicio&posts='.$i.'">'.$i.'</a></li>';
		} 
	}

		echo '<li><a href="?pagina=inicio&posts='.$pg.'">'.$pg.'</a></li>';

		for($i = $pg + 1; $i <= $pg + $links; $i++)
			if($i > $pags){}else{
			echo '<li><a href="?pagina=inicio&posts='.$i.'">'.$i.'</a></li>';
			}

			echo '<li><a href="?pagina=inicio&posts='.$pags.'" aria-label="Última página"><span aria-hidde="true">&raquo;</span></a></li>';
		?>
	</ul>
</nav> 