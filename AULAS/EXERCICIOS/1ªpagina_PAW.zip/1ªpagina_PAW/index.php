<!DOCTYPE html>
<html>

<head>
    <!-- metadados -->
    <title>Apresentação PAW</title>
    <meta charset="utf-8">
    <meta name="description" content="Apresentação do Projeto Final">
    <meta name="keywords" content="IPCA, PAW, Projeto, Final">
    <meta name="author" content="Lara Ribeiro | Luís Pereira | Maria Francisca Costa">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/x-icon" href="resources/images/favicon.ico">

    <!-- CSS -->
    <link rel="stylesheet" href="css/main.css">

    <!-- JQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

    <!-- JS -->
    <script type="text/javascript" src="js/main.js"></script>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css">
    <link rel="stylesheet" type="text/css" href="style.css" media="screen" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
</head>

<body>
    <div class="imagem">
       <h1 class="projeto"> Projeto Final - Publicação e Administração Web</h1>
       <p class="identificacao">Lara Ribeiro | Luís Pereira | Maria Costa</p>
   </div>

   <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Windows Server
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="#">A</a>
              <a class="dropdown-item" href="#">A</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="#">Something else here</a>
          </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Ubuntu
      </a>
      <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">A</a>
          <a class="dropdown-item" href="#">A</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
      </div>
  </li>
</ul>
<form class="form-inline my-2 my-lg-0">
  <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
  <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
</form>
</div>
</nav>
<br>
<h3>Resumo</h3>
<br>
<p>No âmbito da unidade curricular de Publicação e Administração Web, foi proposto um trabalho prático final de avaliação que consiste na criação de duas máquinas virtuais em que teríamos de instalar dois sistemas operativos distintos: Windows Server 2016 e Ubuntu.</p>
<p>Após a sua instalação seria necessário proceder as suas configurações, como a instalação de servidores de email, DHCP, FTP, entre outros.</p>
<br>
<h3>Introdução</h3>
<br>
<p>O presente trabalho tem como principal objetivo implementar os conceitos adquiridos ao longo da unidade curricular de Publicação e Administração Web, instalando e configurando Servidores Web e a implementação de um Website dinâmico.</p>
<p>Ao longo do desenvolvimento do projeto, iremos também efetuar algumas pesquisas de modo a enriquecemos melhor o presente projeto, incluídas funcionalidades novas.</p>
<br>
<h3>Contextualização</h3>
<br>
<p>O projeto consiste na instalação e configuração de dois sistemas operativos, o Windows Server 2016 e o Ubuntu, em máquinas virtuais, utilizando o Virtual Box.</p>
<p>Numa primeira fase iremos organizar-nos a  nível de tarefas, de seguida iremos criar as máquinas virtuais e consequentemente a instalação dos sistemas operativos. Numa última fase, iremos partir para a criação do website dinâmico. </p>
<br>
<h3>Principais Objetivos</h3>
<br>
<p>Com o desenvolvimento deste trabalho, temos como foco principal do grupo a superação das nossas dificuldades e a interajuda.</p>
<p>É nosso objetivo pôr em prática o aprendizado durante as aulas até à presente data, utilizando como recurso principal as fichas fornecidas pelo docente da disciplina.</p>
<br>
<h3>Estrutura do Documento</h3>
<br>
<p>O presente documento serve como relatório do desenvolvimento do projeto final de avaliação da unidade curricular de PAW.</p>
<p>Este documento encontra-se estruturado da seguinte maneira:</p>
<ol>
    <li>Partes cruciais da estrutura de um documento, como um Resumo, Índice de Figuras e Índice de Conteúdos, bem como a Bibliografia.</li>
    <li>Introdução: O projeto é contextualizado, são definidos os objetivos do projeto e a motivação para o desenvolvimento do mesmo, assim como a estrutura do documento.</li>
    <li>Estado de Arte: Aqui apresentamos um pouco de informação sobre Servidores Web e os Sistemas Operativos Ubuntu e Windows Server 2016.</li>
    <li>Realização do Projeto: Ao longo do documento, em vários tópicos subdivididos, são apresentadas todos os passos que compõem o projeto em si.</li>
    <li>Conclusão: Terminaremos este relatório, referindo as lições aprendidas ao longo do desenvolvimento do projeto e faço uma apreciação global do meu trabalho.</li>
</ol>
<br>
<h3>Recursos Utilizados</h3>
<br>
<p>Para a criação deste projeto procuramos usar ferramentas e aplicações com que já estivéssemos familiarizadas, poupando tempo na aprendizagem das mesmas.</p>
<ul>
    <li>Pretendemos utilizar o <b>Dropbox</b> para armazenamento de ficheiros e de backups, facilitando o trabalho de equipa.</li>
    <li>Para a criação deste documento, a ferramenta utilizada é o <b>Microsoft Office Word</b>.</li>
    <li>Todo os passos desenvolvidos foram feitos através da <b>Virtual Box </b> com os sistemas operativos <b>Ubuntu</b> e o <b>Windows Server 2016 e o Windows 10 </b> onde estão instaladas as máquinas virtuais.</li>
    <li>A publicação do site online feita no <b>InfinityFree</b> desenvolvido com o <b>WordPress</b>.</li>
</ul>
<br>
<h3>Estado de Arte</h3>
<h4>Servidores Web</h4>
<br>
<p>Um Servidor Web é responsável por responder a todas as solicitações feitas para um endereço na internet.</p>
<p>O termo Servidor Web resulta em sois tipos distintos: Servidor Web como <b>hardware</b> e Servidor Web como <b>software</b>.</p>
<br>
<h4>Servidores Web como Hardware</h4>
<br>
<p>Para poder hospedar um site, é necessário existir um compilador de arquivos digitais, sendo estes interpretados pelo navegador de internet.</p>
<p>Em termos de equipamentos físicos, podem ser encontrados em dois tipos diferentes, em Torre, que caíram em desuso pela criação dos grandes Data Centre, o que resultou na criação do outro tipo de equipamento, Racks, tendo assim a capacidade de agrupar e interligar dezenas de servidores.</p>
<br>
<h4>Servidores Web como Software</h4>
<br>
<p>Servidores Web como softwares, tem como objetivo principal aceitar os pedidos HTTP provenientes dos navegadores, transmitindo-os como respostas em HTTP, como dados das páginas web ou documentos em HTML.</p>
<p>Existem diversos tipos de servidores web, sejam eles gratuitos ou pagos. O mais popular é o Apache, existindo também o XAMPP, Nginx e o Microsoft IIS.</p>
<br>
<h4>Páginas Dinâmicas e Páginas Estáticas</h4>
<br>
<p>Os dados enviados pelo servidor web podem ser em dois diferentes tipos:</p>


<section class="grelha">
 <div>
  <article>
   <figure>
    <img src="dinamicas.png" border="0">
</figure>
<span>
    <p>Dinamicas</p>
    <label>Quando o ficheiro de origem está contido diretamente no servidor.</label>
</span>
</article>

<article>
   <figure>
    <img src="estaticas.jpg" border="0">
</figure>
<span>
    <p>Estaticas</p>
    <label>Quando os dados são criados dinamicamente por um programa (script ou API). Neste caso, existe a vantagem de estas serem programadas, usando assim uma linguagem de programação (podendo ser: php, Java, C# …). </label>
</span>
</article>
</div>
</section>

<br>

<h3 align="center"> Windows Server 2016, Ubuntu e Wordpress</h3>


<section class="grelha">
   <div>
      <article>
         <figure>
            <img src="server.jpg" border="0">
        </figure>
        <span>
            <h3 align="center">Windows Server 2016</h3>
            <label>O Windows Server 2016 foi desenvolvido pela Microsoft e faz parte da família de SO Windows NT. É assim, um sistema desenvolvido para servidores.
            O lançamento da primeira versão ocorreu no dia 01 de outubro de 2014, sendo que a versão final foi apresentada a 26 de setembro de 2016, ficando disponível para o público a 12 de outubro de 2016, cerca de 2 anos após o primeiro lançamento.</label>
        </span>
    </article>
    <article>
     <figure>
        <img src="ubuntu1.jpg" border="0">
    </figure>
    <span>
       <h3 align="center">Ubuntu</h3>
       <label>Ubuntu é um  sistema operativo de código aberto, construído a partir do núcleo Linux, baseado no Debian.A proposta do Ubuntu é oferecer um sistema que qualquer pessoa possa utilizar sem dificuldades, independentemente de nacionalidade, nível de conhecimento ou limitações físicas.
       A primeira versão do Ubuntu, lançada em 20 de outubro de 2004, o Ubuntu 4.10, intitulada de The Warty Warthog (O Porco-africano Verruguento) e a versão mais atual do ubuntu saiu em 23 de abril de 2020, o Ubuntu 20.04LTS, intitulada de Focal Fossa.</label>
   </span>
</article>
<article>
 <figure>
    <img src="Wordpress.jpg" border="0">
</figure>
<span>
    <h3 align="center">Wordpress</h3>
    <label>WordPress é um CMS (Content Management System), que em português significa Sistema de Gerenciamento de Conteúdo. 
        Em outras palavras, é um sistema usado para administrar sites, blogs, lojas virtuais, portais de notícia, áreas de membros e outros tipos de página. O objetivo do CMS é gerenciar o conteúdo de forma simples e prática.
    Desde a versão 0.70 até a 5.2.2 (lançada em junho de 2019), foram mais de 75 atualizações que melhoraram a usabilidade do sistema e o tornaram mais seguro.</label>
</span>
</article>
</div>
</section>






<footer class="footer">
 &copy; 2020 ApresentaçãoPublicação&AdministraçãoWeb
</footer>

</body>
</html>